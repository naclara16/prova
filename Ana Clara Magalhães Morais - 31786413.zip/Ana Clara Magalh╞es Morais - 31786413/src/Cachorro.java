public class Cachorro extends Pet {
    private String porte;
    private String corPelo;

    public String getPorte() {
        return porte;
    }
    public void setPorte(String porte) {
        this.porte = porte;
    }
    public String getCorPelo() {
        return corPelo;
    }
    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }
    @Override
    public String toString() {
        return "Cachorro [porte=" + porte + ", corPelo=" + corPelo + "]";
    }

    /**
     * 
     */
    public void print(){
        System.out.println("------------------------");
        System.out.println("Nome: " + getNome() + "\n" + "Raça: " + getRaca() + "\n" + "Idade: " + getIdade() + "\n" + "Porte: " + getPorte() + "\n" + "Tutor: " + getTutor() + "\n" + "Cor: " + getCorPelo() + "\n");
    }
   
    
    
}
