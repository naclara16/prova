import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        Cachorro c = new Cachorro();
        Gato g = new Gato();
        Scanner leia = new Scanner(System.in);

        int escolha;
        char resp = 'N';
        while (resp == 'N') {
            System.out.println("** \t\t\t PET  ** \n");
            System.out.println("1 - Cachorro");
            System.out.println("2 - Gato");
            System.out.println("3 - Sair");
            System.out.print("Digite a opção desejada: ");
            escolha = leia.nextInt();

            switch (escolha) {
                case 1:
                    System.out.println("-----------------------");
                    System.out.println("Cachorro");
                    System.out.println("Digite o nome do Cachorro: ");
                    c.setNome(leia.next());
                    System.out.println("Digite a Raça: ");
                    c.setRaca(leia.next());
                    System.out.println("Digite a idade: ");
                    c.setIdade(leia.nextInt());
                    System.out.println("Digite o Porte: ");
                    c.setPorte(leia.next());
                    System.out.println("Digite o nome do Tutor: ");
                    c.setTutor(leia.next());
                    System.out.println("Digite a cor do pelo: ");
                    c.setCorPelo(leia.next());
                    c.print();
                    break;

                case 2:
                    System.out.println("--------------------------------");
                    System.out.println("Gato");
                    System.out.println("Digite o nome do Gato: ");
                    g.setNome(leia.next());
                    System.out.println("Digite a Raça: ");
                    g.setRaca(leia.next());
                    System.out.println("Digite a idade: ");
                    g.setIdade(leia.nextInt());
                    System.out.println("Digite o nome do Tutor: ");
                    g.setTutor(leia.next());
                    System.out.println("Digite a cor do pelo: ");
                    g.setCorPelo(leia.next());
                    g.print();
                    break;

                case 3:
                    do {
                        System.out.print("Tem certeza que quer sair do Programa? (S/N)");
                        resp = leia.next().toUpperCase().charAt(0);
                    } while (resp != 'N' && resp != 'S');
                    break;
                default:
                    System.out.println("Invalido");
                    System.out.println("Tente novamente");
                    break;

            }

        }
        System.out.println("Fim");
        leia.close();
    }
}
