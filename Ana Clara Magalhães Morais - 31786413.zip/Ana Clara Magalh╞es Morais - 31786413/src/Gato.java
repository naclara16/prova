public class Gato extends Pet {
    private String corPelo;

    public String getCorPelo() {
        return corPelo;
    }

    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }

    @Override
    public String toString() {
        return "Gato [corPelo=" + corPelo + "]";
    }
    
    public void print(){
        System.out.println("------------------------");
        System.out.println("Nome: " + getNome() + "\n" + "Raça: " + getRaca() + "\n" + "Idade: " + 
        getIdade() + "\n" + "Tutor: " + getTutor() + "\n" + "Cor: " + getCorPelo() + "\n"
          );
    }

}
